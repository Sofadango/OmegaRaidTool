﻿$files = GCI "C:\Users\Hagen\source\repos\GrasslinOmega\GrasslinOmega\bin\Debug\*.ini" | select -Property Fullname 


foreach($filename in $files)
{

    $michipups = GC $filename.FullName 
    "" | Out-File  $filename.FullName -Encoding utf8
    foreach($line in $michipups)
    {
        $newpups = $line
        if ($line -match "fps_limit"){
                Write-Host $line
            $newpups = $line.Replace($line, "fps_limit=15")
                    Write-Host $newpups
        }
        $newpups| Out-File $filename.FullName -Encoding utf8 -Append  

    }
}



